#include "JsonObject.h"
#include "string.h"
#include <stdio.h>
#include <stdlib.h>

JsonObject::JsonObject()
{
    //ctor
    lastPosition = 1;
    numOfValues = 0;
}

JsonObject::~JsonObject()
{
    //dtor
}

void JsonObject::Put(const char* name, const char* value){

    int j, k = lastPosition;

    if(k>1){
        objectString[lastPosition] = ','; lastPosition++;
        k++;
    }


    objectString[lastPosition] = '\"'; lastPosition++;

    for(j=0; lastPosition<= strlen(name)+k; lastPosition++){
        objectString[lastPosition] = name[j];
        j++;
    }

    objectString[lastPosition] = '\"'; lastPosition++;
    objectString[lastPosition] = ':'; lastPosition++;
    objectString[lastPosition] = '\"'; lastPosition++;

    k = lastPosition-1;

    for(j=0; lastPosition<= strlen(value)+k; lastPosition++){
        objectString[lastPosition] = value[j];
        j++;
    }

    objectString[lastPosition] = '\"'; lastPosition++;
    objectString[lastPosition] = '}';// lastPosition++;
}

void JsonObject::Put(const char* name, bool value){

    int j, k = lastPosition;

    if(k>1){
        objectString[lastPosition] = ','; lastPosition++;
        k++;
    }

    objectString[lastPosition] = '\"'; lastPosition++;

    for(j=0; lastPosition<= strlen(name)+k; lastPosition++){
        objectString[lastPosition] = name[j];
        j++;
    }

    objectString[lastPosition] = '\"'; lastPosition++;
    objectString[lastPosition] = ':'; lastPosition++;

    if(value){
        objectString[lastPosition] = 't'; lastPosition++;
        objectString[lastPosition] = 'r'; lastPosition++;
        objectString[lastPosition] = 'u'; lastPosition++;
        objectString[lastPosition] = 'e'; lastPosition++;
    }else {
        objectString[lastPosition] = 'f'; lastPosition++;
        objectString[lastPosition] = 'a'; lastPosition++;
        objectString[lastPosition] = 'l'; lastPosition++;
        objectString[lastPosition] = 's'; lastPosition++;
        objectString[lastPosition] = 'e'; lastPosition++;
    }

    objectString[lastPosition] = '}';// lastPosition++;
}

void JsonObject::Put(const char* name, int value){

    int j, k = lastPosition;
    static char number[11];

    if(k>1){
        objectString[lastPosition] = ','; lastPosition++;
        k++;
    }

    objectString[lastPosition] = '\"'; lastPosition++;

    for(j=0; lastPosition<= strlen(name)+k; lastPosition++){
        objectString[lastPosition] = name[j];
        j++;
    }

    objectString[lastPosition] = '\"'; lastPosition++;
    objectString[lastPosition] = ':'; lastPosition++;

    k = lastPosition-1;

    sprintf(number, "%d", value);

    for(j=0; lastPosition<= strlen(number)+k; lastPosition++){
        objectString[lastPosition] = number[j];
        j++;
    }

    objectString[lastPosition] = '}';// lastPosition++;
}


void JsonObject::GetStringValue(const char* key, char* value){

	GetKeyValue(key,value);

}

bool JsonObject::GetBoolValue(const char* key){

	char x[5];

	GetKeyValue(key, x);

	if(x[0] == 't'){
		return true;
	}

	return false;
}

int JsonObject::GetIntValue(const char* key){

	char x[100];

	GetKeyValue(key, x);

	return atoi(x);
}

void JsonObject::GetIdValue(const char* key, char* value) {

	char sbbuff[50];
	GetKeyValue(key,sbbuff);

	int i;
	for(i=6; i<strlen(sbbuff) -1; i++){
		value[i-6] = sbbuff[i];

	}
	value[i-5] = '\0';

//	memcpy( value, &sbbuff[6], strlen(sbbuff) -7);

}

void JsonObject::GetArrayIdsValues(const char* key, const char* values, int size) {
	int i=0,j=0;
	char name[25];
	bool found = false;
	int lenght = 0;
	int state=0;
	char valueAux[100];

	lenght = strlen(objectString);

	/*
	 * 0. look for object start '{'
	 * 1. look for key start '"'
	 * 2. copy key and look for object end '"'
	 * 3. look for ':'
	 * 4. copy value and look for ',' or '}'
	 *
	 * {teste:123,teste1:"werwerw"}
	 *
	 */

	memset(name, '\0', sizeof(name));

	while(!found && i<= lenght){

		switch (state) {
			case 0:
				if(objectString[i] == '{'){
					state = 1;
				}
				break;
			case 1:
				if(objectString[i] == '\"'){
					state = 2;
				}
				break;
			case 2:
				if(objectString[i] != '\"'){
					name[j] = objectString[i];
					j++;
				}else{
					printf("tag:%s\n", name);
					j=0;
					state = 3;
				}
				break;
			case 3:
				if(objectString[i] == ':'){
					state = 4;
				}
				break;
			case 4:
				if(objectString[i] == '['){
					state = 5;
				}else {
					memset(name, '\0', sizeof(name));
					memset(valueAux, '\0', sizeof(valueAux));
					j=0;
					state = 1;
				}
				break;
			case 5:
				if((objectString[i] != ']')){
					if(objectString[i] != '\"'){
						valueAux[j] = objectString[i];
						j++;
					}
				}else {
					if(strcmp(name, key) == 0){
						found = true;
						printf("achou!!!!!!!!!!:\n");
						//printf("%s\n",valueAux);
						//strcpy(value, valueAux);
					}else if(objectString[i] == ','){
						printf("igual a virgula\n");
						memset(name, '\0', sizeof(name));
						memset(valueAux, '\0', sizeof(valueAux));
						j=0;
						state = 1;
					}else {
						printf("name:%s\n", name);
						printf("not found\n");
						break;//not found
					}
				}
				break;
			default:
				break;
		}

		i++;
	}



}


void JsonObject::GetKeyValue(const char* key, char* value){
	int i=0,j=0;
	char name[25];
	bool found = false;
	int lenght = 0;
	int state=0;
	char valueAux[100];

	lenght = strlen(objectString);
	memset(value, '\0', sizeof(value));

	/*
	 * 0. look for object start '{'
	 * 1. look for key start '"'
	 * 2. copy key and look for object end '"'
	 * 3. look for ':'
	 * 4. copy value and look for ',' or '}'
	 *
	 * {teste:123,teste1:"werwerw"}
	 *
	 */



	while(!found && i<= lenght){

		switch (state) {
			case 0:
				if(objectString[i] == '{'){
					state = 1;
				}
				break;
			case 1:
				if(objectString[i] == '\"'){
					state = 2;
				}
				break;
			case 2:
				if(objectString[i] != '\"'){
					name[j] = objectString[i];
					j++;
				}else{
					j=0;
					state = 3;
				}
				break;
			case 3:
				if(objectString[i] == ':'){
					state = 4;
				}
				break;
			case 4:
				if((objectString[i] != ',') && (i != lenght)){
					if(objectString[i] != '\"'){
						valueAux[j] = objectString[i];
						j++;
					}
				}else {
					if(strcmp(name, key) == 0){
						found = true;
						strcpy(value, valueAux);
					}else if(objectString[i] == ','){
						memset(name, '\0', sizeof(name));
						memset(valueAux, '\0', sizeof(valueAux));
						j=0;
						state = 1;
					}else {
						break;//not found
					}
				}
				break;
			default:
				break;
		}

		i++;
	}

}


char* JsonObject::ToString(){
    return objectString;
}
