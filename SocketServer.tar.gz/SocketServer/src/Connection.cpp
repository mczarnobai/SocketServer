#include "Connection.h"

Connection::Connection()
{
    //ctor
    memset(buffer, '\0', sizeof(buffer));
    com = new Communication();
}

Connection::~Connection()
{
    //dtor
	delete this->com;
}
