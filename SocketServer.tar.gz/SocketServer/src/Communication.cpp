#include "Communication.h"
#include <exception>

#include <bsoncxx/builder/stream/document.hpp>
#include <bsoncxx/json.hpp>

#include <mongocxx/client.hpp>
#include <mongocxx/instance.hpp>

#include <bsoncxx/oid.hpp>>
#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/builder/basic/sub_array.hpp>
#include <bsoncxx/exception/exception.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <mongocxx/instance.hpp>
#include <json.hpp>

#include "JsonObject.h"
#include <iostream>
#include "string.h"
#include <syslog.h>

using bsoncxx::builder::stream::close_array;
using bsoncxx::builder::stream::close_document;
using bsoncxx::builder::stream::document;
using bsoncxx::builder::stream::finalize;
using bsoncxx::builder::stream::open_array;
using bsoncxx::builder::stream::open_document;

using json_lib = nlohmann::json;

Communication::Communication()
{
	this->crypto = new CryptoLib();
	this->json = {'\0'};
}

Communication::~Communication()
{
    //dtor
}

void Communication::DecryptMessage(){

	crypto->Decrypt(json);

}

void Communication::SendDataToReadAsync(char* data, char* responseData)
{
	this->json = data;

	//this->DecryptMessage();

	//syslog(LOG_INFO, "antes de imprimir\n.");

//    printf("socket: %d data:",0);
//    for(unsigned int i=0; i<strlen(json); i++){
//        printf("%c",json[i]);
//    }

    json_lib dataJson;
    json_lib device;
    json_lib hourmeterDevice;
    bool error = false;

    syslog(LOG_INFO, "variaveis json definidas\n.");

    try{
    	syslog(LOG_INFO, "comecando a fazer o parse\n.");
    	dataJson = json_lib::parse(std::string(data));
    	syslog(LOG_INFO, "fez o parse\n.");
    	printf("fez o parse");
    }catch (...) {
    	syslog(LOG_ERR, "Error on parsing json data from device.\n");
    	std::cout << "Exception0" << "\n";
    	error = true;
    }

    syslog(LOG_INFO, "comecando a se conectar no banco\n.");
   // mongocxx::uri uri("mongodb://0.0.0.0:27017");
    //mongocxx::client conn{uri};

    mongocxx::instance inst{};
    syslog(LOG_INFO, "criou instancia\n.");
    mongocxx::client conn(mongocxx::uri{});
    syslog(LOG_INFO, "conectou uri\n.");

    bsoncxx::builder::stream::document document{};
    bsoncxx::document::view_or_value value;

    syslog(LOG_INFO, "comecando a buscar collection\n.");

    // find device by imei
    auto collection = conn["gprs"]["veiculos"];

    if(!error){
    	try{
    	    std::string sImei = dataJson["imei"];

    	    mongocxx::stdx::optional<bsoncxx::document::value> maybe_result
    			= collection.find_one(document << "imei" << sImei << finalize);

    		if(maybe_result) {
    			device = json_lib::parse(bsoncxx::to_json(*maybe_result));
    		}else{
    			std::cout << "maybe_result null" << "\n";
    			error = true;
    		}
    	}catch (...) {
    		syslog(LOG_ERR, "Error on find device by imei\n.");
        	std::cout << "Exception1" << "\n";
        	error = true;
		}
    }

    //update device

    if(!error){
       	try{
       		syslog(LOG_INFO, "atualizando banco\n.");
       		std::string sId = device["_id"]["$oid"];
       		bool bTravas = dataJson["travas"];
			bool bAlarme = dataJson["alarme"];
			int iMotor = dataJson["tempoMotorLigado"];
			std::string lLatitude = dataJson["latitude"];
			std::string lLongitude = dataJson["longitude"];

       		mongocxx::stdx::optional<mongocxx::result::update> result = collection.update_one(document << "_id" << bsoncxx::oid(sId) << finalize,
								  document << "$set" << open_document
								    << "travas" << bTravas
								    << "alarme" << bAlarme
									<< "tempoMotorLigado" << iMotor
									<< "latitude" << lLatitude
									<< "longitude" << lLongitude
									<< close_document << finalize);
			if(result){
				std::cout << "conseguiu atualizar" << "\n";
			}else {
				error = true;
			}
       	}catch (...) {
       		syslog(LOG_ERR, "Error on update device\n.");
           	std::cout << "Exception2" << "\n";
           	error = true;
   		}
       }

    if(!error){
       	try{
       	    std::string sImei = dataJson["imei"];

       	    mongocxx::stdx::optional<bsoncxx::document::value> maybe_result
       			= collection.find_one(document << "imei" << sImei << finalize);

       		if(maybe_result) {
       			device = json_lib::parse(bsoncxx::to_json(*maybe_result));
       		}else{
       			std::cout << "maybe_result null" << "\n";
       			error = true;
       		}
       	}catch (...) {
       		syslog(LOG_ERR, "Error on find device by imei\n.");
           	std::cout << "Exception1" << "\n";
           	error = true;
   		}
       }


	JsonObject writeObject;
	if(!error){
		syslog(LOG_INFO, "respondendo ok\n.");
		writeObject.Put("status", "OK");
		writeObject.Put("bloqueio", (bool) device["bloqueio"]);
	}else{
		syslog(LOG_INFO, "respondendo erro\n.");
		writeObject.Put("status", "ERROR");
	}

	strcpy(responseData, writeObject.ToString());
}
