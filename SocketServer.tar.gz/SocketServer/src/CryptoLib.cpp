#include "CryptoLib.h"

CryptoLib::CryptoLib()
{
    //ctor
}

CryptoLib::~CryptoLib()
{
    //dtor
}

void CryptoLib::Encrypt(char* message){

    int aux=0;

    for(int i=0; i < strlen(message) ; i++){

        if(aux >13){
            aux=0;
        }

        if(aux< 4){
            message[i] ^= key[aux + 2];
        }
        else if(aux< 6){
            message[i] ^= key[aux];
        }else if(aux<10){
            message[i] ^= key[aux+1];
        }else{
            message[i] ^= key[aux];
        }
        aux++;
    }
}

void CryptoLib::Decrypt(char* message){
    int aux=0;

    for(int i=0; i< strlen(message); i++){

        if(aux >13){
            aux=0;
        }

        if(aux< 4){
            message[i] ^= key[aux + 2];
        }
        else if(aux< 6){
            message[i] ^= key[aux];
        }else if(aux<10){
            message[i] ^= key[aux+1];
        }else{
            message[i] ^= key[aux];
        }
        aux++;
    }
}
