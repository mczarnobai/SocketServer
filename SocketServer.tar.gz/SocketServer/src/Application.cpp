#include "Application.h"

Application::Application()
{

}

Application::~Application()
{
    //dtor
}

void Application::Start(){
    Initialize();
}

void Application::Initialize(){
    this->mySocket = new MySocket();
    this->mySocket->Start();
}
