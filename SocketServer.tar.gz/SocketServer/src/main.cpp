//============================================================================
// Name        : main.cpp
// Author      : Miguel C.
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Application.h"
#include "stdio.h"
#include <syslog.h>

using namespace std;

int main() {

	syslog(LOG_NOTICE, "Main socket server c++ application\n");
	printf("Main socket server c++ application\n");
    Application app;
    app.Start();

	return 0;
}
