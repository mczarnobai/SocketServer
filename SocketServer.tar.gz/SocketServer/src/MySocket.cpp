#include "MySocket.h"
#include <fcntl.h>
#include "stdio.h"
#include <syslog.h>
MySocket::MySocket()
{
	addr_size = 0;
    //ctor
}

MySocket::~MySocket()
{
    //dtor
}

int numberConnections = 0;

void* MySocket::Run(void *param){


	syslog(LOG_INFO, "new connection run\n");
	printf("new connection");

    Connection *connection = (Connection*) param;

    int closedFlag = 0;

    while (connection->GetRes() > 0)
    {
    	printf("getting response");
    	syslog(LOG_INFO, "getting response\n");

        connection->SetRes(recv(connection->GetNewSocket(), connection->buffer, sizeof(connection->buffer), 0));


        if (connection->GetRes() > 0)
        {

            connection->GetCom()->SendDataToReadAsync(connection->buffer, connection->dataToWrite);

            memset(connection->buffer, '\0', sizeof(connection->buffer));

            syslog(LOG_INFO, "server sending response\n");
            printf("server seding response");

            send(connection->GetNewSocket(),connection->dataToWrite,strlen(connection->dataToWrite),0);

            close(connection->GetNewSocket());
            closedFlag = 1;
            printf("connection closed by server");
            syslog(LOG_INFO, "connection closed by server\n");
            numberConnections--;
            syslog(LOG_INFO, "Connections:%d\n", numberConnections);

        }else
        {
        	syslog(LOG_INFO, "without response\n");
        }
    }

    if(!closedFlag){
        close(connection->GetNewSocket());
        printf("Connection closed with not closed flag");
        syslog(LOG_INFO, "Connection closed with not closed flag: %d\n", connection->GetNewSocket());
        numberConnections--;
        syslog(LOG_INFO, "Connections:%d\n", numberConnections);
    }

    delete connection;
    syslog(LOG_INFO, "exit pthread\n");
    pthread_exit(NULL);
}

int MySocket::Start(){

    //WSAStartup (MAKEWORD(2,2), &wsaData);
    /*---- Create the socket. The three arguments are: ----*/
    /* 1) Internet domain 2) Stream socket 3) Default protocol (TCP in this case) */
    welcomeSocket = socket(PF_INET, SOCK_STREAM, 0);
    if (welcomeSocket < 0)
    {
      syslog(LOG_ERR, "Error on creating socket %d.\n", welcomeSocket);
    }

//    fcntl(welcomeSocket, F_SETFL, fcntl(welcomeSocket, F_GETFL, 0) | O_BLOCK);

    /*---- Configure settings of the server address struct ----*/
    /* Address family = Internet */
    serverAddr.sin_family = AF_INET;
    /* Set port number, using htons function to use proper byte order */
    serverAddr.sin_port = htons(8080);
    /* Set IP address to localhost */
    serverAddr.sin_addr.s_addr = inet_addr("0.0.0.0");//135
    /* Set all bits of the padding field to 0 */
    memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);


    /*---- Bind the address struct to the socket ----*/
    syslog(LOG_INFO, "Connecting to port 8080, try number:1.\n");
    error = bind(welcomeSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));

    int tryes = 1;
	while(error < 0){
		tryes++;
		syslog(LOG_ERR, "Error on bind address, error code:%d.\n", error);
		syslog(LOG_INFO, "Connecting to port 8080, try number:%d.\n", tryes);
    	error = bind(welcomeSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));
    	sleep(5);
    }

	printf("Listening\n");

    while (1)
    {
        if(listen(welcomeSocket,200)==0){
        	syslog(LOG_INFO, "Listening ok status 200.\n");
        	printf("Listening ok\n");
        }else {
            printf("Error\n");
          	syslog(LOG_ERR, "Error on listening connection.\n");
          }

      /*---- Accept call creates a new socket for the incoming connection ----*/
      addr_size = sizeof(clientAddr);
      newSocket = accept(welcomeSocket, (struct sockaddr *)&clientAddr, &addr_size);

      Connection* c = new Connection();
      c->SetNewSocket(newSocket);
      c->SetMySocket(this);

      pthread_t t;
      syslog(LOG_INFO, "Creating thread\n");
      numberConnections++;
      syslog(LOG_INFO, "Connections:%d\n", numberConnections);
      pthread_create(&t, NULL, &MySocket::Run, (void *) c);

    }
}
