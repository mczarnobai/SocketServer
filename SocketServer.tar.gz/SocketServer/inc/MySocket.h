

//#include <winsock.h>
//#include <winsock2.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "Connection.h"

#ifndef MYSOCKET_H
#define MYSOCKET_H

#define THREADS_MAX 200

class MySocket
{
    public:
        MySocket();
        virtual ~MySocket();

        static void* Run(void *param);
        int Start();

    protected:

    private:
        int welcomeSocket, newSocket;
        char buffer[1024];
        struct sockaddr_in serverAddr, clientAddr;
        socklen_t addr_size;
        int error;
        //WSADATA wsaData;
        pthread_t threads[THREADS_MAX];
        int thread_args;
        char rxBuffer[1024];
        int count = 0;
        int res = 1;
};

#endif // MYSOCKET_H
