#ifndef COMMUNICATION_H
#define COMMUNICATION_H

#include <stdio.h>
#include <string.h>
#include "CryptoLib.h"
#include <exception>

class Communication
{
    public:
        Communication();
        virtual ~Communication();

        void SendDataToReadAsync(char* data, char* dataToWrite);

    protected:

    private:
        int mode;
        char* json;
        CryptoLib* crypto;

        void DecryptMessage();
};

#endif // COMMUNICATION_H
