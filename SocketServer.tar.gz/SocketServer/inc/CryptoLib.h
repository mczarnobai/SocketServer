#ifndef CRYPTOLIB_H
#define CRYPTOLIB_H

#include <string.h>
class CryptoLib
{
    public:
        CryptoLib();
        virtual ~CryptoLib();
        void Encrypt(char* message);
        void Decrypt(char* message);
    protected:

    private:
        char key[16] = "ASJFKVMRTHWLPQO";
};

#endif // CRYPTOLIB_H
