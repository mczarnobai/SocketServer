#ifndef APPLICATION_H
#define APPLICATION_H

#include "MySocket.h"


class Application
{
    public:
        Application();
        virtual ~Application();
        void Start();

    private:
        MySocket* mySocket;

        void Initialize();
};

#endif // APPLICATION_H
