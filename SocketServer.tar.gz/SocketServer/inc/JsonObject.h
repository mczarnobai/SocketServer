#ifndef JSONOBJECT_H
#define JSONOBJECT_H

#include <string.h>

class JsonObject
{
    public:
        JsonObject();
        virtual ~JsonObject();
        void Put(const char* name, const char* value);
        void Put(const char* name, bool value);
        void Put(const char* name, int value);
        void GetKeyValue(const char* key, char* value);
        void SetObjectString(char* value) { strcpy(objectString, value); }
        char* ToString();

        void GetStringValue(const char* key, char* value);
        bool GetBoolValue(const char* key);
        int GetIntValue(const char* key);
        void GetIdValue(const char* key, char* value);
        void GetArrayIdsValues(const char* key, const char* values, int size);

    protected:

    private:



        char objectString[256] = {'{','}'};
        int numOfValues;
        int lastPosition;

};

#endif // JSONOBJECT_H
