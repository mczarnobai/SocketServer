#ifndef CONNECTION_H
#define CONNECTION_H

#include "MySocket.h"
#include "Communication.h"


class Connection
{
    public:
        Connection();
        virtual ~Connection();

        const int& GetNewSocket() { return newSocket; }
        void SetNewSocket(int value) { newSocket = value; }

        const int& GetRes() { return res; }
        void SetRes(int value) { res = value; }

        const int& GetCount() { return count; }
        void SetCount(int value) { count = value; }

        MySocket* GetMySocket() { return mSocket; }
        void SetMySocket(MySocket *value) { mSocket = value; }

        Communication* GetCom() { return com; }
        void SetCom(Communication *value) { com = value; }

        char buffer[512];
        char dataToWrite[256];

    protected:

    private:
        int newSocket, res=1, count=0;
        MySocket* mSocket;
        Communication* com;
};

#endif // CONNECTION_H
